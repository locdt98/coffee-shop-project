'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { ILoai } from '@/app/(site)/components/cautrucdata';

const LoaiList = () => {
  const token = localStorage.getItem("token")
  const [dsLoai, setDsLoai] = useState<ILoai[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const perPage = 3;
  
  const [ napLai,  setNapLai ] = useState(0);
  useEffect(() => {
    const opt:RequestInit = { 
          method:"get",  
          credentials: "include", 
          headers:{ 'Authorization':'Bearer '+ token}
    }
    const fetchData = async () => {
        const res = await fetch('http://localhost:3000/admin/loai' ,  opt );
        const data = await res.json();
        setDsLoai(data);
    }
    fetchData();
  }, [ napLai ]);

  const totalPages = Math.ceil(dsLoai.length / perPage);
  const startIndex = (currentPage - 1) * perPage;
  const currentData = dsLoai.slice(startIndex, startIndex + perPage);

  const handleXoa = (id:number) => {
    if (window.confirm("Xóa thật không vậy?")===false) return;
    fetch( `http://localhost:3000/admin/loai/${id}`, {"method":"delete" , headers: { Authorization: `Bearer ${token}` } })
    .then( res => res.json() )
    .then( data  => {  //{'thong_bao':'Đã xóa loại', trang_thai:1}
      if (data.trang_thai!=1) alert(data.thong_bao)
      else setNapLai( napLai + 1 ) 
    })
  }

  return (
    <div className="w-full px-10 py-6 bg-white shadow-lg rounded-xl">
      <h2 className="text-2xl font-semibold mb-4 text-center text-blue-700">Danh sách các loại</h2>
      <table className="table-auto w-full border border-gray-300">
        <thead className="bg-blue-100">
          <tr className="text-left">
            <th className="p-2 border">ID</th>
            <th className="p-2 border">Hình</th>
            <th className="p-2 border">Tên loại</th>
            <th className="p-2 border">Thứ tự</th>
            <th className="p-2 border">Ẩn hiện</th>
            <th className="p-2 border">Xem SP</th>
            <th className="p-2 border">Sửa</th>
            <th className="p-2 border">Xóa</th>
          </tr>
        </thead>
        <tbody>
          {currentData.map((loai) => (
            <tr key={loai.id} className="hover:bg-gray-100">
              <td className="p-2 border">{loai.id}</td>
              <td className="p-2 border w-[80px]">
                <img src={loai.hinh.startsWith('http')? loai.hinh : `http://localhost:3000${loai.hinh}`}
                alt={loai.ten_loai}  className="border rounded h-[45px] w-[45px]"/>
              </td>
              <td className="p-2 border">{loai.ten_loai}</td>
              <td className="p-2 border text-center">{loai.thu_tu}</td>
              <td className="p-2 border text-center">
                {loai.an_hien ? 'Đang hiện' : 'Đang ẩn'}
              </td>
              <td className="p-2 border text-blue-600 underline text-center">
                <Link href={`/admin/san-pham?loai_id=${loai.id}`}>Xem SP</Link>
              </td>
              <td className="p-2 border text-center">
               <Link href={`/admin/loai/${loai.id}`}>
               <button className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-yellow-500"> Sửa
               </button>
               </Link>
              </td>
              <td className="p-2 border text-center">
                <button  onClick={() => handleXoa(loai.id)}
                  className="px-3 py-1 bg-red-400 text-white rounded hover:bg-red-600" > Xóa
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Phân trang */}
      <div className="flex justify-center mt-4 space-x-2">
        {Array.from({ length: totalPages }, (_, i) => (
          <button  key={i} onClick={() => setCurrentPage(i + 1)}
            className={`px-3 py-1 border rounded ${currentPage === i + 1
            ? 'bg-blue-500 text-white' :'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >{i + 1} </button>
        ))}
      </div>
    </div>
  );
};

export default LoaiList;
