import SuaLoai from "./SuaLoai";

export default async function Page( {params}:{ params:{id:number}  } ) {
  const { id }  = await params
  return <SuaLoai id= {id} />;
}
