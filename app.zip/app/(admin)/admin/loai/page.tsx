import LoaiList from './LoaiList';
export default function DanhSachLoaiPage() {
    
  return <LoaiList />;
}
