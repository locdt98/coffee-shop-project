'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ThemLoai() {
  const token = localStorage.getItem("token")
  const [ten_loai, setTenLoai] = useState('');
  const [slug, setSlug] = useState('');
  const [thu_tu, setThuTu] = useState(1);
  const [an_hien, setAnHien] = useState(1);
  const [mo_ta, setMoTa] = useState('');
  const [hinh, setHinh] = useState<File | null>(null);
  const [previewHinh, setPreviewHinh] = useState<string | null>(null);

  const router = useRouter();

  const handleTenLoaiChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setTenLoai(value);
    setSlug(
      value.toLowerCase().normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, '-')
        .replace(/[^a-z0-9\-]/g, '')
    );
  };

  const handleHinhChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setHinh(file);
      setPreviewHinh(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async () => {
    const formData = new FormData();
    formData.append('ten_loai', ten_loai);
    formData.append('slug', slug);
    formData.append('thu_tu', thu_tu.toString());
    formData.append('an_hien', an_hien.toString());
    formData.append('mo_ta', mo_ta);
    if (hinh) formData.append('hinh', hinh);

    const res = await fetch('http://localhost:3000/admin/loai', {
      method: 'POST',
      body: formData,
      headers:{ 'Authorization':'Bearer '+ token}
    });
    const result = await res.json();
    alert(result.thong_bao || 'Không có thông báo từ server');
    if (result.trang_thai==1) router.push("/admin/loai")
  };

  return (
    <div className="w-[90%] mx-auto p-4 bg-white text-[#3e2f23] rounded-2xl shadow-md space-y-6">
      <h1 className="text-2xl font-bold mb-4 text-center">➕ Thêm loại sản phẩm</h1>
      <div className="grid grid-cols-2 gap-6">
        <div>
          <label className="block mb-2">✏️ Tên loại</label>
          <input type="text" value={ten_loai} minLength={2}  maxLength={50} required
            onChange={handleTenLoaiChange}
            className="w-full border border-gray-300 px-3 py-2 rounded outline-none"/>
        </div>
        <div>
          <label className="block mb-2">🔗 Slug</label>
          <input type="text" value={slug} 
            onChange={(e) => setSlug(e.target.value)}
            className="w-full border border-gray-300 px-3 py-2 rounded outline-none"/>
        </div>
        <div>
          <label className="block mb-2">🔢 Thứ tự</label>
          <input type="number" value={thu_tu} min={1}
            onChange={(e) => setThuTu(Number(e.target.value))}
            className="w-full border border-gray-300 px-3 py-2 rounded outline-none"/>
        </div>
        <div>
          <label className="block mb-2">👁️‍🗨️ Ẩn / Hiện</label>
          <select value={an_hien}
            onChange={(e) => setAnHien(Number(e.target.value))}
            className="w-full border border-gray-300 px-3 py-2 rounded outline-none" >
            <option value={1}>Hiện</option>
            <option value={0}>Ẩn</option>
          </select>
        </div>
        <div className="col-span-2 flex gap-6 items-start">
          <div className="w-1/2">
            <label className="block mb-2">📝 Mô tả</label>
            <textarea value={mo_ta}  maxLength={200}  rows={5} 
              onChange={(e) => setMoTa(e.target.value)}
              className="w-full border border-gray-300 px-3 py-2 rounded outline-none"/>
          </div>
          <div className="w-1/2">
            <label className="block mb-2">🖼️ Hình ảnh</label>
            <input type="file" accept="image/*" onChange={handleHinhChange} 
            className='w-full border border-gray-300 px-3 py-2 rounded outline-none' />
            {previewHinh && (
             <img src={previewHinh} className="border rounded object-cover h-[80px] w-[80px]"/>
            )}
          </div>
        </div>
      </div>

      <div className="flex justify-center gap-6 pt-4">
        <button onClick={handleSubmit}
          className="bg-amber-500 font-bold px-6 py-2 rounded hover:bg-red-800" >➕ Thêm loại
        </button>
        <a href="/admin/loai"
          className="bg-cyan-500 text-white px-6 py-2 rounded hover:bg-gray-700">📋 Danh sách loại
        </a>
      </div>
    </div>
 )}
