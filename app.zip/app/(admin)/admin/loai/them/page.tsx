import ThemLoai from "./ThemLoai";
export default function Page() {
  
  return <ThemLoai />;
}
