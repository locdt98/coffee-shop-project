"use client";
import { useRouter } from "next/navigation";

export default function NutXoaSP( { id }: { id: number } ) {
  const token = localStorage.getItem("token")
  const router = useRouter();
  const hamXoa = async () => {
    if (!confirm("Xóa sp này hả?")) return;
    const res = await fetch(`http://localhost:3000/admin/san_pham/${id}`, 
      {method:"DELETE", headers: { Authorization: `Bearer ${token}` }})
    const result = await res.json();
    alert(result.thong_bao)
    if (result.trang_thai==1) router.refresh();
  };
  return (
    <button onClick={hamXoa} 
    className='bg-amber-600 my-2 px-3 py-1 text-center text-white w-full'> Xóa </button>
)}
