import Link from "next/link";
import NutXoaSP from "./NutXoaSP";
import { cookies } from 'next/headers'; 
import SelectLoai from "./SelectLoai";

export default async function DanhSachSP({ searchParams }: { searchParams: { page?: string , id_loai:number } }){
    const cookieStore = await cookies(); // Truy cập cookies trong môi trường server
    const token = (await cookieStore).get('token')?.value;  // Lấy giá trị cookie "token"
    const opt:RequestInit = { 
      method:"get",  
      credentials: "include", 
      headers:{ 'Authorization':'Bearer '+ token}
    }


    const page = Number((await searchParams).page) || 1;
    const id_loai= await (searchParams).id_loai || -1;
    const limit = 3; //perPage , page_size, limit
    const res = await fetch(`http://localhost:3000/admin/san_pham?page=${page}&id_loai=${id_loai}`, opt);
    const dataSP = await res.json();
    let sp_arr = dataSP.listsp; //1 trang dữ liệu
    let total = dataSP.total;    //tổng số reord
    const totalPages = Math.ceil(total / limit);
    const resLoai = await fetch(`http://localhost:3000/admin/san_pham/laycacloai`, opt)
    const loai_arr = await resLoai.json();
    const laytenloai = function ( id_loai:number) {
        if (loai_arr.length === 0) return "Không có";
        let kq = loai_arr.find( (item:any) => Number(item.id) === id_loai);
        if (kq!=null) return kq.ten_loai; else return "Không có";
    }
return (
<div  className="w-full p-4 bg-white shadow-lg rounded-xl">
  <h2 className="text-2xl font-semibold mb-4 text-center text-blue-700">Danh sách sản phẩm</h2>
  <div className='flex bg-cyan-700 py-2 text-white text-center'>
      <b className="w-[200px]">Hình</b> 
      <b className="flex-1">Tên SP / SKU
          <span className="float-end">
          <SelectLoai id_loai={id_loai} loai_arr={loai_arr}></SelectLoai> 
          Số SP: { total}
          </span>  
  
      </b> 
      <b className="w-[200px]">Thông tin </b>  
      <b className="w-[90px]"><Link href="/admin/san_pham/them">Thêm</Link></b>
  </div>
    { /* phân trang*/}
  <div className="flex justify-end mt-4 gap-4">
    {page > 1 && (
        <Link href={`/admin/san_pham?page=${page - 1}`}
        className="px-4 py-1 bg-cyan-700 text-white rounded">Trang trước </Link>
    )}
    <span className="px-4 py-1 border rounded"> {page} / {totalPages} </span>
    {page < totalPages && (
        <Link href={`/admin/san_pham?page=${page + 1}`}
        className="px-4 py-1 bg-cyan-700 text-white rounded">Trang sau </Link>
    )}
  </div>
  {sp_arr.map( (sp:any, index:number) => (
    <div className='flex mb-2 border p-2 rounded' key={index}>
        <div className="w-[200px] me-2"> 
            <img src={sp.hinh.startsWith('http')? sp.hinh : `http://localhost:3000${sp.hinh}`} 
            alt={sp.ten_sp} className="w-100 h-[120px]"/> 
        </div> 
        <div className="flex-1">
          <p>Tên SP: <b>{sp.ten_sp}</b> </p>
          <p>SKU: <b>{sp.sku}</b> </p>          
          <p>Loại: {laytenloai(sp.id_loai) } </p>
          <p>Tags: {sp.tags} </p>
        </div>          
        <div className="w-[200px]">
          <p> Giá : {sp.gia.toLocaleString("vi")} VNĐ </p>
          <p>Cập nhật: {new Date(sp.updated_at).toLocaleDateString("vi")}</p>           
          <p>Trạng thái : {sp.an_hien===1? "Đang ẩn":"Đang hiện"}</p>
          <p>Lượt xem: {sp.luot_xem} </p>        
        </div>
        <div className="w-[90px]">
          <NutXoaSP id={sp.id}></NutXoaSP>
         <Link href={"/admin/san_pham/"+sp.id} 
           className='bg-cyan-700 block my-2 px-3 py-1 text-white text-center' >Sửa</Link>
        </div>
    </div>
 ))}
  { /* phân trang*/}
  <div className="flex justify-start mt-4 gap-4">
    {page > 1 && (
        <Link href={`/admin/san_pham?page=${page - 1}`}
        className="px-4 py-1 bg-cyan-700 text-white rounded">Trang trước </Link>
    )}
    <span className="px-4 py-1 border rounded"> {page} / {totalPages} </span>
    {page < totalPages && (
        <Link href={`/admin/san_pham?page=${page + 1}`}
        className="px-4 py-1 bg-cyan-700 text-white rounded">Trang sau </Link>
    )}
  </div>

</div>
)}

