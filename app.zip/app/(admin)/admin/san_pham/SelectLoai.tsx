"use client";
import { ILoai } from "@/app/(site)/components/cautrucdata";

export default function SelectLoai( {id_loai, loai_arr} : { id_loai:number, loai_arr:ILoai[]} ){
return(
<select name="id_loai" defaultValue={id_loai} className="mr-2 bg-cyan-50 p-1 text-black text-sm"
onChange={e => location.href=`/admin/san_pham?id_loai=${e.target.value}` } >
    <option value="-1">Tất cả loại</option>  
    { loai_arr.map ( loai => <option key={loai.id} value={loai.id}>  {loai.ten_loai} </option>) }
</select>
)} 
