'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ThemSanPham() {
  const token = localStorage.getItem("token")
  const [loaiList, setLoaiList] = useState<any[]>([]);
  const [hinh, setHinh] = useState<File | null>(null);
  const [previewHinh, setPreviewHinh] = useState<string | null>(null);
  const [hinh_phu, setHinhPhu] =useState<File[]>([]);
   const [previewHinhPhu, setPreviewHinhPhu] = useState<string[]>([]);
  const [ten_sp, setTenSP] = useState('');
  const [gia, setGia] = useState('');
  const [sku, setSKU] = useState('');
  const [slug, setSlug] = useState('');
  const [an_hien, setAnHien] = useState(true);
  const [hot, setHot] = useState(false);
  const [id_loai, setLoai] = useState('0');
  const [luot_xem, setLuotXem] = useState(0);
  const [so_luong, setSoLuong] = useState(0);
  const [thanh_phan, setThanhPhan] = useState('');
  const [huong_vi, setHuongVi] = useState('');
  const [khoi_luong, setKhoiLuong] = useState('');
  const [huong_dan_bao_quan, setBaoQuan] = useState('');
  const [han_su_dung, setHanSuDung] = useState('');
  const [tags, setTags] = useState('');
  const router = useRouter();
  useEffect(() => {
    const opt:RequestInit = { 
      method:"get",  
      credentials: "include", 
      headers:{ 'Authorization':'Bearer '+ token}
    }
    fetch('http://localhost:3000/admin/loai', opt)
      .then(res => res.json())
      .then(data => setLoaiList(data));
  }, []);

  useEffect(() => {
    const s = ten_sp.trim().toLowerCase().replace(/\s+/g, '-').replace(/[^\w\-]+/g, '');
    setSlug(s);
  }, [ten_sp]);

  const handleHinh = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
     if (file) {
      setHinh(file);
      setPreviewHinh(URL.createObjectURL(file));
    }
  };

  const handleHinhPhu = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const listURL = Array.from(files).map(file => URL.createObjectURL(file));
      setPreviewHinhPhu(listURL);
      const listFile = Array.from(files);
      setHinhPhu(listFile);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("ten_sp", ten_sp);
    formData.append("slug", slug);
    formData.append("sku", sku);
    formData.append("gia", gia.toString());
    formData.append("id_loai", id_loai.toString());
    formData.append("an_hien", an_hien.toString());
    formData.append("hot", hot.toString());
    formData.append("luot_xem", luot_xem.toString());
    formData.append("so_luong", so_luong.toString());
    formData.append("thanh_phan", thanh_phan);
    formData.append("huong_vi", huong_vi);
    formData.append("khoi_luong", khoi_luong);
    formData.append("huong_dan_bao_quan", huong_dan_bao_quan);
    formData.append("han_su_dung", han_su_dung);
    formData.append("tags", tags); // Nếu bạn dùng dấu phẩy ngăn cách

    // Hình chính
    if (hinh) formData.append("hinh", hinh);

    // Hình phụ
    if (hinh_phu && hinh_phu.length > 0) {
      for (let i = 0; i < hinh_phu.length; i++) {
        formData.append("hinh_phu", hinh_phu[i]);
      }
    }

    try {
      const res = await fetch("http://localhost:3000/admin/san_pham", {
        method: "POST",
        body: formData,
        headers: { Authorization: `Bearer ${token}` },
      });
      const result = await res.json();
      alert (result.thong_bao || "Không có thông báo")
      if (result.trang_thai===1) router.push("/admin/san_pham")
    } catch (error) {
      console.log("Lỗi gửi dữ liệu:", error);
      alert("Có lỗi khi gửi dữ liệu.");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full mx-auto bg-white p-3 shadow rounded space-y-3">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">➕ Thêm sản phẩm</h2>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label>📛 Tên sản phẩm</label>
          <input value={ten_sp} onChange={e => setTenSP(e.target.value)} minLength={2} maxLength={50}
            className="w-full border p-2 rounded" required />
        </div>
        <div>
          <label>🔗 Slug</label>
          <input value={slug} onChange={e => setSlug(e.target.value)}
          readOnly={false} className="w-full border p-2 rounded" />
        </div>
        <div>
          <label>🔢 Giá </label>
          <input type="number" min={1} value={gia} onChange={e => setGia(e.target.value)}
            className="w-full border p-2 rounded" required />
        </div>
        <div>
          <label>🏷️ SKU</label>
          <input value={sku} onChange={e => setSKU(e.target.value)}
          className="w-full border p-2 rounded" required />
        </div>
        <div>
          <label>📂 Loại</label>
          <select className="w-full border p-2 rounded" required value={id_loai} 
          onChange={e => setLoai(e.target.value)}>
            <option value="">-- Chọn loại --</option>
            {loaiList.map(loai => (
              <option key={loai.id} value={loai.id}>{loai.ten_loai}</option>
            ))}
          </select>
        </div>
        <div>
          <label>🏷️ Tags</label>
          <input value={tags} onChange={e => setTags(e.target.value)}
          className="w-full border p-2 rounded" />
        </div>
        <div>
          <label>🍃 Thành phần</label>
          <input value={thanh_phan} onChange={e => setThanhPhan(e.target.value)}
          className="w-full border p-2 rounded" />
        </div>
        <div>
          <label>🍬 Hương vị</label>
          <input value={huong_vi} onChange={e => setHuongVi(e.target.value)}
          className="w-full border p-2 rounded" />
        </div>
        <div>
          <label>⚖️ Khối lượng</label>
          <input value={khoi_luong} onChange={e => setKhoiLuong(e.target.value)}
          className="w-full border p-2 rounded" />
        </div>
        <div>
          <label>📦 Hướng dẫn bảo quản</label>
          <input value={huong_dan_bao_quan}  onChange={e => setBaoQuan(e.target.value)}
          className="w-full border p-2 rounded" />
        </div>
        <div>
          <label>📅 Hạn sử dụng</label>
          <input value={han_su_dung}  onChange={e => setHanSuDung(e.target.value)}
          className="w-full border p-2 rounded" />
        </div>
        <div className='grid grid-cols-2 gap-2'>
          <div>
            <label>👁️ Ẩn/Hiện</label>
            <div className="flex gap-4 border p-2">
              <label><input type="radio" name="an_hien" value="1" defaultChecked /> Hiện</label>
              <label><input type="radio" name="an_hien" value="0" /> Ẩn</label>
            </div>
          </div>
          <div >
            <label>🔥 Hot</label>
            <div className="flex gap-4 border p-2">
              <label><input type="radio" name="hot" value="0" defaultChecked /> Bình thường</label>
              <label><input type="radio" name="hot" value="1" /> Nổi bật</label>
            </div>
          </div>
        </div>
      </div>

      {/* Hình và hình phụ nằm cùng hàng */}
      <div className="grid grid-cols-2 gap-4 items-start">
        <div>
          <label>🖼️ Hình đại diện</label>
          <input type="file" name="hinh" accept="image/*" onChange={handleHinh}
            className="w-full border p-2 rounded" />
          {previewHinh && (
            <img src={previewHinh} alt="Hình đại diện" className="border rounded h-[60px]" />
          )}
        </div>
        <div>
          <label>🖼️ Hình phụ</label>
          <input type="file" name="hinh_phu" accept="image/*" multiple onChange={handleHinhPhu}
            className="w-full border p-2 rounded" />
          <div className="flex gap-2 mt-2 flex-wrap">
            {previewHinhPhu.map((src, i) => (
              <img key={i} src={src} className="border rounded h-[60px]" />
            ))}
          </div>
        </div>
      </div>

      {/* Các nút */}
      <div className="flex justify-center gap-6">
        <button type="submit"
         className="bg-amber-500 font-bold px-6 py-2 rounded hover:bg-red-800" >➕ Thêm sản phẩm
        </button>
        <a href="/admin/san_pham"
         className="bg-cyan-500 text-white px-6 py-2 rounded hover:bg-gray-700">📋 Danh sách sản phẩm
        </a>
      </div>
    </form>
)}
