export default function HomeAdmin(){
return(
<h1>Trang chủ admin</h1>
)}
