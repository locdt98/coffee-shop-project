import "./admin.css";
import Link from "next/link";
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';


export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const tenDangNhap = "Nguyễn Văn Long";
  //const cookieStore = await cookies();
  //const token = cookieStore.get('token')?.value; 
  //const tenDangNhap= cookieStore.get('ho_ten')?.value; 
  //if (!token || !tenDangNhap)  redirect('/login'); //chưa đăng nhập, chuyển về login

  const today = new Date().toLocaleDateString("vi-VN", {
    weekday: "long", day: "2-digit", month: "2-digit", year: "numeric",
  });
return (
<html lang="vi">
  <body className="bg-[#f3f4f6]">
        <div className="min-h-screen bg-[#f5e6d3] text-[#3e2f23] flex flex-col">
      {/* Header */}
       <header className="bg-[#6a0000] text-white p-4 md:flex justify-between">
            <h1 className="text-xl font-semibold">
              <Link href="/admin" className="hover:text-green-300">☕ Admin-Coffee & Tea Zen</Link>
            </h1>
            <div className="flex items-center gap-4 text-sm">
              <span>{tenDangNhap}</span>
              <span>{today}</span>
              <Link href="/" className="hover:underline">🌐 Phần site</Link>
              <Link href="/logout" className="hover:underline">🚪 Thoát</Link>
            </div>
        </header>

      <div className="flex flex-1">
        {/* Sidebar */}
        <aside className="w-64 bg-[#3e2f23] text-[#f5e6d3] p-4 space-y-4 text-sm">
          {/* Quản trị loại */}
          <div>
            <div className="font-semibold mb-1">📂 Quản trị loại</div>
            <Link href="/admin/loai/them" className="block ml-4 hover:bg-[#6a0000] rounded px-2 py-1">➕ Thêm loại</Link>
            <Link href="/admin/loai" className="block ml-4 hover:bg-[#6a0000] rounded px-2 py-1">📄 Danh sách các loại</Link>
          </div>

          {/* Quản trị sản phẩm */}
          <div>
            <div className="font-semibold mb-1">📦 Quản trị sản phẩm</div>
            <Link href="/admin/san_pham/them" className="block ml-4 hover:bg-[#6a0000] rounded px-2 py-1">➕ Thêm sản phẩm</Link>
            <Link href="/admin/san_pham " className="block ml-4 hover:bg-[#6a0000] rounded px-2 py-1">📄 Danh sách sản phẩm</Link>
          </div>

          {/* Quản trị bình luận */}
          <div>
            <div className="font-semibold mb-1">💬 Quản trị bình luận</div>
            <Link href="/admin/binh_luan " className="block ml-4 hover:bg-[#6a0000] rounded px-2 py-1">📄 Danh sách bình luận</Link>
          </div>

          {/* Quản trị đơn hàng */}
          <div>
            <div className="font-semibold mb-1">🧾 Quản trị đơn hàng</div>
            <Link href="/admin/don_hang " className="block ml-4 hover:bg-[#6a0000] rounded px-2 py-1">📄 Danh sách đơn hàng</Link>
          </div>

          {/* Quản trị banner */}
          <div>
            <div className="font-semibold mb-1">🖼️ Quản trị banner</div>
            <Link href="/admin/banner/them" className="block ml-4 hover:bg-[#6a0000] rounded px-2 py-1">➕ Thêm banner</Link>
            <Link href="/admin/banner" className="block ml-4 hover:bg-[#6a0000] rounded px-2 py-1">📄 Danh sách banner</Link>
          </div>

          {/* Quản trị bài viết */}
          <div>
            <div className="font-semibold mb-1">📝 Quản trị bài viết</div>
            <Link href="/admin/bai_viet/them" className="block ml-4 hover:bg-[#6a0000] rounded px-2 py-1">➕ Thêm bài viết</Link>
            <Link href="/admin/bai_viet" className="block ml-4 hover:bg-[#6a0000] rounded px-2 py-1">📄 Danh sách bài viết</Link>
          </div>

          {/* Quản trị user */}
          <div>
            <div className="font-semibold mb-1">👤 Quản trị user</div>
            <Link href="/admin/user/them" className="block ml-4 hover:bg-[#6a0000] rounded px-2 py-1">➕ Thêm user</Link>
            <Link href="/admin/user" className="block ml-4 hover:bg-[#6a0000] rounded px-2 py-1">📄 Danh sách user</Link>
          </div>
        </aside>

        {/* Main content */}
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  </body>
</html>
)}
