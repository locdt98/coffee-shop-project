'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useParams } from 'next/navigation';
import { param } from 'framer-motion/client';
export default function SuaBanner() {
  const token = localStorage.getItem("token")
  let params = useParams();
  let id = params.id;
  useEffect( () =>  { 
    const opt:RequestInit = { 
        method:"get",  
        credentials: "include", 
        headers:{ 'Authorization':'Bearer '+ token}
    }
    fetch(`http://localhost:3000/admin/banner/${id}`, opt)
    .then (res => res.json())
    .then( data => {
        if (data.thong_bao!=undefined){
          alert(data.thong_bao); 
          return;
        }
        setTitle(data.title)
        setThuTu(data.thu_tu)
        setAnHien(data.an_hien==true? 1:0)
        setHinh(data.hinh)
        setPreviewHinh(data.hinh.startsWith('http')? data.hinh : `http://localhost:3000${data.hinh}`)
    })
  }, [] )
  const [title, setTitle] = useState('');
  const [thu_tu, setThuTu] = useState(1);
  const [an_hien, setAnHien] = useState(1);
  const [hinh, setHinh] = useState<File | null>(null);
  const [previewHinh, setPreviewHinh] = useState<string | null>(null);
  const router = useRouter();

  const handleHinhChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setHinh(file);
      setPreviewHinh(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async () => {
   if (!hinh){ alert("Bạn chưa chọn hình"); return }
    const formData = new FormData();
    formData.append('title', title);
    formData.append('thu_tu', thu_tu.toString());
    formData.append('an_hien', an_hien.toString());
    formData.append('hinh', hinh);

    const res = await fetch(`http://localhost:3000/admin/banner/${id}`, {
      method: 'PUT',
      body: formData,
      headers:{ 'Authorization':'Bearer '+ token}
    });
    const result = await res.json();
    alert(result.thong_bao || 'Không có thông báo từ server');
    if (result.trang_thai==1) router.push("/admin/banner")
  };

  return (
    <div className="w-3/4 mx-auto p-4 bg-white text-[#3e2f23] rounded-2xl shadow-md space-y-6">
      <h1 className="text-2xl font-bold mb-4 text-center">✏️ Sửa banner</h1>
      <div>
        <label className="block mb-2">✏️ Tiêu đề</label>
        <input onChange={ e => setTitle(e.target.value)} type="text" value={title} 
          className="w-full border border-gray-300 px-3 py-2 rounded outline-none"/>
      </div>
      <div>
        <label className="block mb-2">🔢 Thứ tự</label>
        <input type="number" value={thu_tu} min={1}
          onChange={(e) => setThuTu(Number(e.target.value))}
          className="w-full border border-gray-300 px-3 py-2 rounded outline-none"/>
      </div>
      <div>
        <label className="block mb-2">👁️‍🗨️ Ẩn / Hiện</label>
        <select value={an_hien}
          onChange={(e) => setAnHien(Number(e.target.value))}
          className="w-full border border-gray-300 px-3 py-2 rounded outline-none" >
          <option value={1}>Hiện</option>
          <option value={0}>Ẩn</option>
        </select>
      </div>
      <div>
        <label className="block mb-2">🖼️ Hình ảnh</label>
        <input type="file" accept="image/*" onChange={handleHinhChange} 
        className='w-full border border-gray-300 px-3 py-2 rounded outline-none' />
        {previewHinh && (
          <img src={previewHinh} className="border rounded object-cover h-[80px] w-[80px]"/>
        )}
      </div>
      <div className="flex justify-center gap-6 pt-4">
        <button onClick={handleSubmit}
          className="bg-amber-500 font-bold px-6 py-2 rounded hover:bg-red-800" >✏️ Cập nhật banner
        </button>
        <a href="/admin/banner"
          className="bg-cyan-500 text-white px-6 py-2 rounded hover:bg-gray-700">📋Danh sách banner
        </a>
      </div>
    </div>
 )}
