import Link from "next/link";
import NutXoaBV from "./NutXoaBV";
import { IBaiViet } from "@/app/(site)/components/cautrucdata";
import { cookies } from "next/headers";

export default async function DanhSachBV({ searchParams }: { searchParams: { page?: string  } }){
    const cookieStore = await cookies(); // Truy cập cookies trong môi trường server
    const token = (await cookieStore).get('token')?.value;  // Lấy giá trị cookie "token"
    
    const opt:RequestInit = { 
      method:"get",  
      credentials: "include", 
      headers:{ 'Authorization':'Bearer '+ token}
    }
    const page = Number( await (searchParams).page) || 1;
    const res = await fetch(`http://localhost:3000/admin/bai_viet?page=${page}`, opt);
    const data = await res.json();
    let { listbv, total } = data;

    let page_size = 3
    const totalPages = Math.ceil(total / page_size);

return (
<div  className="w-full p-4 bg-white shadow-lg rounded-xl">
  <h2 className="text-2xl font-semibold mb-4 text-center text-blue-700">Danh sách bài viết</h2>
  <div className='flex bg-cyan-700 py-2 text-white text-center'>
      <b className="w-[200px]">Hình</b> 
      <b className="flex-1">Tiêu đề</b> 
      <b className="w-[200px]">Thông tin </b>  
      <b className="w-[90px]"><Link href="/admin/bai_viet/them">Thêm</Link></b>
  </div>
{listbv.map( (bv:IBaiViet) => (
    <div className='flex mb-2 border p-2 rounded' key={bv.id}>
        <div className="w-[200px] me-2"> 
            <img src={bv.hinh.startsWith('http')? bv.hinh : `http://localhost:3000${bv.hinh}`} 
            alt={bv.tieu_de} className="w-100 h-[120px] border"/> 
        </div> 
        <div className="flex-1">
          <h3 className="font-bold">{bv.tieu_de} </h3>         
          <p>slug: <i>{bv.slug} </i></p>
          <p>id : {bv.id}</p>
        </div>          
        <div className="w-[200px]">
          <p>Ẩn hiện : { bv.an_hien? "Đang ẩn":"Đang hiện"}</p>
          <p>Hot : { bv.hot? "Tin nổi bật":"Bình thường"}</p>
          <p>Lượt xem: { bv.luot_xem } </p>        
        </div>
        <div className="w-[100px]">
         <NutXoaBV id={bv.id}></NutXoaBV>
         <Link href={"/admin/bai_viet/" + bv.id} 
           className='bg-cyan-700 block my-2 px-3 py-1 text-white text-center' >Sửa</Link>
        </div>
    </div>
 ))}
{ /* phân trang*/}
<div className="flex justify-center mt-4 gap-4">
   {page > 1 && (
      <Link href={`/admin/bai_viet?page=${page - 1}`}
      className="px-4 py-1 bg-cyan-700 text-white rounded">Trang trước </Link>
   )}
   <span className="px-4 py-1 border rounded"> {page} / {totalPages} </span>
   {page < totalPages && (
      <Link href={`/admin/bai_viet?page=${page + 1}`}
       className="px-4 py-1 bg-cyan-700 text-white rounded">Trang sau </Link>
   )}
</div>
{ /* phân trang */}

</div>
)}
