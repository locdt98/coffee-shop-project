'use client';
import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';

export default function SuaBaiViet() {
  const token = localStorage.getItem("token")
  const router = useRouter();
  const params = useParams();
  const id = Number(params["id"]);

  const [hinh, setHinh] = useState<File | null>(null);
  const [previewHinh, setPreviewHinh] = useState<string | null>(null);
  const [tieu_de, setTieuDe] = useState('');
  const [slug, setSlug] = useState('');
  const [an_hien, setAnHien] = useState(true);
  const [hot, setHot] = useState(false);
  const [luot_xem, setLuotXem] = useState(0);
  const [noi_dung, setNoiDung] = useState('');

  // Load dữ liệu sản phẩm
  useEffect(() => {
    const opt:RequestInit = { 
      method:"get",  
      credentials: "include", 
      headers:{ 'Authorization':'Bearer '+ token}
    }
    fetch(`http://localhost:3000/admin/bai_viet/${id}` , opt)
    .then(res => res.json()).then(data => {
        setTieuDe(data.tieu_de || '');
        setSlug(data.slug || '');
        setAnHien(data.an_hien);
        setHot(data.hot);
        setLuotXem(data.luot_xem);
        setNoiDung(data.noi_dung || '');
        if (data.hinh) setPreviewHinh( data.hinh.startsWith('http')? data.hinh : `http://localhost:3000${data.hinh}` );
    });
  }, [id]);

  useEffect(() => {
    const s = tieu_de.trim().toLowerCase().replace(/\s+/g, '-').replace(/[^\w\-]+/g, '');
    setSlug(s);
  }, [tieu_de]);

  const handleHinh = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setHinh(file);
      setPreviewHinh(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("tieu_de", tieu_de);
    formData.append("slug", slug);
    formData.append("an_hien", an_hien.toString());
    formData.append("hot", hot.toString());
    formData.append("luot_xem", luot_xem.toString());
    formData.append("noi_dung", noi_dung);
    if (hinh) formData.append("hinh", hinh);

    try {
      const res = await fetch(`http://localhost:3000/admin/bai_viet/${id}`, {
        method: "PUT",
        body: formData,
        headers:{ 'Authorization':'Bearer '+ token}
      });
      const result = await res.json();
      alert(result.thong_bao || "Không có thông báo");
      if (result.trang_thai === 1) router.push("/admin/bai_viet");
    } catch (error) {
      console.log("Lỗi gửi dữ liệu:", error);
      alert("Có lỗi khi sửa dữ liệu.");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full mx-auto bg-white p-3 shadow rounded space-y-3">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">✏️ Sửa bài viết</h2>
      <div className="grid grid-cols-1 gap-4">
        <div>
          <label>📛 Tiêu đề</label>
          <input value={tieu_de} onChange={e => setTieuDe(e.target.value)} minLength={2} maxLength={80}
            className="w-full border p-2 rounded" required />
        </div>
        <div>
          <label>🔗 Slug</label>
          <input value={slug} onChange={e => setSlug(e.target.value)}
          className="w-full border p-2 rounded" />
        </div>
        <div className='grid grid-cols-2 gap-2'>
          <div>
            <label>👁️ Ẩn/Hiện</label>
            <div className="flex gap-4 border p-2">
              <label><input type="radio" name="an_hien" value="true" checked={an_hien === true} onChange={() => setAnHien(true)} /> Hiện</label>
              <label><input type="radio" name="an_hien" value="false" checked={an_hien === false} onChange={() => setAnHien(false)} /> Ẩn</label>
            </div>
          </div>
          <div >
            <label>🔥 Hot</label>
            <div className="flex gap-4 border p-2">
              <label><input type="radio" name="hot" value="false" checked={hot === false} onChange={() => setHot(false)}  /> Bình thường</label>
              <label><input type="radio" name="hot" value="true" checked={hot === true} onChange={() => setHot(true)} /> Nổi bật</label>
            </div>
          </div>
        </div>
      </div>
      <div>
        <label>🖼️ Hình đại diện</label>
        <input type="file" name="hinh" accept="image/*" onChange={handleHinh}
          className="w-full border p-2 rounded" />
        {previewHinh && (
          <img src={previewHinh} alt="Hình đại diện" className="border rounded h-[60px]" />
        )}
      </div>
      <div>
        <label>📝 Nội dung</label>
        <textarea value={noi_dung || ''}  maxLength={200}  rows={5} 
          onChange={ e => setNoiDung(e.target.value)}
          className="w-full border border-gray-300 px-3 py-2 rounded outline-none"/>
      </div>
      
      {/* Nút submit/reset */}
      <div className="flex justify-center gap-6">
        <button type="submit"
          className="bg-amber-500 font-bold px-6 py-2 rounded hover:bg-red-800" >✏️ Lưu cập nhật
        </button>
        <a href="/admin/bai_viet"
        className="bg-cyan-500 text-white px-6 py-2 rounded hover:bg-gray-700">📋Danh sách bài viết
        </a>
      </div>
    </form>
  );
}

