'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ThemBaiViet() {
  const token = localStorage.getItem("token")
  const [hinh, setHinh] = useState<File | null>(null);
  const [previewHinh, setPreviewHinh] = useState<string | null>(null);
  const [tieu_de, setTieuDe] = useState('');
  const [slug, setSlug] = useState('');
  const [an_hien, setAnHien] = useState(true);
  const [hot, setHot] = useState(false);
  const [luot_xem, setLuotXem] = useState(0);
  const [noi_dung, setNoiDung] = useState('');

  const router = useRouter();

  useEffect(() => {
    const s = tieu_de.trim().toLowerCase().replace(/\s+/g, '-').replace(/[^\w\-]+/g, '');
    setSlug(s);
  }, [tieu_de]);

  const handleHinh = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
     if (file) {
      setHinh(file);
      setPreviewHinh(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("tieu_de", tieu_de);
    formData.append("slug", slug);
    formData.append("an_hien", an_hien.toString());
    formData.append("hot", hot.toString());
    formData.append("luot_xem", luot_xem.toString());
    formData.append("noi_dung", noi_dung);
    if (hinh) formData.append("hinh", hinh);

    try {
      const res = await fetch("http://localhost:3000/admin/bai_viet", {
        method: "POST",
        body: formData,
        headers:{ 'Authorization':'Bearer '+ token}
      });
      const result = await res.json();
      alert (result.thong_bao || "Không có thông báo")
      if (result.trang_thai===1) router.push("/admin/bai_viet")
    } catch (error) {
      console.log("Lỗi gửi dữ liệu:", error);
      alert("Có lỗi khi gửi dữ liệu.");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full mx-auto bg-white p-3 shadow rounded space-y-3">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">➕ Thêm bài viết</h2>
      <div className="grid grid-cols-1 gap-4">
        <div>
          <label>📛 Tiêu đề</label>
          <input value={tieu_de} onChange={e => setTieuDe(e.target.value)} minLength={2} maxLength={50}
            className="w-full border p-2 rounded" required />
        </div>
        <div>
          <label>🔗 Slug</label>
          <input value={slug} onChange={e => setSlug(e.target.value)}
          className="w-full border p-2 rounded" />
        </div>
        <div className='grid grid-cols-2 gap-2'>
          <div>
            <label>👁️ Ẩn/Hiện</label>
            <div className="flex gap-4 border p-2">
              <label><input type="radio" name="an_hien" value="1" defaultChecked /> Hiện</label>
              <label><input type="radio" name="an_hien" value="0" /> Ẩn</label>
            </div>
          </div>
          <div >
            <label>🔥 Hot</label>
            <div className="flex gap-4 border p-2">
              <label><input type="radio" name="hot" value="0" defaultChecked /> Bình thường</label>
              <label><input type="radio" name="hot" value="1" /> Nổi bật</label>
            </div>
          </div>
        </div>
      </div>
      <div>
        <label>🖼️ Hình đại diện</label>
        <input type="file" name="hinh" accept="image/*" onChange={handleHinh}
          className="w-full border p-2 rounded" />
        {previewHinh && (
          <img src={previewHinh} alt="Hình đại diện" className="border rounded h-[60px]" />
        )}
      </div>
      <div>
        <label>📝 Nội dung</label>
        <textarea value={noi_dung}  maxLength={200}  rows={5} 
          onChange={(e) => setNoiDung(e.target.value)}
          className="w-full border border-gray-300 px-3 py-2 rounded outline-none"/>
      </div>
      
      {/* Nút submit/reset */}
      <div className="flex justify-center gap-6">
        <button type="submit"
          className="bg-amber-500 font-bold px-6 py-2 rounded hover:bg-red-800" >➕ Thêm bài viết
        </button>
        <a href="/admin/bai_viet"
        className="bg-cyan-500 text-white px-6 py-2 rounded hover:bg-gray-700">📋Danh sách bài viết
        </a>
      </div>
    </form>
  );
}
