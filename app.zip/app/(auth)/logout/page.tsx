'use client'
import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
export default function Logout({ children,}: Readonly<{children: React.ReactNode;}>) {
 const router = useRouter()
  useEffect(() => {
    fetch('http://localhost:3000/auth/logout', {credentials: 'include'}) 
    .then(res => res.json()).then(data => {
        localStorage.clear();
        router.push('/login') // chuyển hướng sau khi logout
    })
  }, [])
return (
  <html lang="vi">
    <body className="bg-[#f5e6d3] text-[#3e2f23] font-sans mt-[100px]">
      <div></div>
    </body>
  </html>
)}
