// admin/login/layout.tsx
import "./dinhdang.css";
export default function RootLayout({ children,}: Readonly<{children: React.ReactNode;}>) {
return (
  <html lang="vi">
    <body className="bg-[#f5e6d3] text-[#3e2f23] font-sans mt-[100px]">
      {children}
    </body>
  </html>
)}
