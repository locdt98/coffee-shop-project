export default function GioiThieu() {
  return (
    <div className="w-5/6 mx-auto p-10 my-5 text-center text-brown-900 bg-amber-50 rounded-xl shadow-md">
      <img src="/logo.png" alt="Logo Cà Phê & Thiền" className="mx-auto mb-6 w-64 h-64 object-contain"/>
      <h1 className="text-3xl font-bold mb-6 text-amber-800">Chào mừng đến với Cà Phê – Trà – Thiền</h1>
      <p className="text-lg leading-relaxed text-gray-700 mb-6">
        Chúng tôi mang đến một không gian thư thái và tĩnh tại, nơi bạn có thể tìm thấy những hạt cà phê rang mộc, 
        những loại trà thảo mộc an lành, và những dòng thiền gợi mở tâm hồn.
      </p>
      <p className="text-lg leading-relaxed text-gray-700 mb-6">
        Website là điểm kết nối những tâm hồn yêu thích sự giản dị, chất lượng và sự bình an trong từng ngụm thức uống. 
        Chúng tôi lựa chọn kỹ càng từ vùng nguyên liệu sạch, thuần tự nhiên, đến cách đóng gói và phục vụ.
      </p>
      <p className="text-lg leading-relaxed text-gray-700 mb-8">
        Ngoài ra, bạn còn có thể tìm thấy dụng cụ pha chế tinh tế, bài viết chia sẻ về nghệ thuật thưởng thức và thiền tập, 
        giúp bạn sống chậm lại, sâu hơn và trọn vẹn hơn từng khoảnh khắc.
      </p>
      <p className="italic text-amber-700">“Một tách cà phê – một phút tĩnh lặng – một đời an nhiên.”</p>
    </div>
  );
}
