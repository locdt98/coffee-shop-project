'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginForm() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [mat_khau, setMatKhau] = useState('');
  const [thongbao, setThongbao] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setThongbao('Đang kiểm tra...');

    const res = await fetch('http://localhost:3000/api/dang_nhap', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({email , mat_khau})
    });

    const data = await res.json();
    if (data.status ==1 ) {
      setThongbao('✅ Đăng nhập thành công, vui lòng chờ...');
      const user = data.user;
      sessionStorage.setItem("user", JSON.stringify(user))
      sessionStorage.setItem("token", data.token)
      window.dispatchEvent(new CustomEvent("login", { detail: user }));
      setTimeout(() => {
        const returnUrl = sessionStorage.getItem('returnUrl') || ""
        if (returnUrl!="") {
          sessionStorage.removeItem('returnUrl')
          router.push(returnUrl) 
        }
        else router.push('/') 
      }, 3000);
    } else {
      setThongbao(`❌ ${data.message || 'Đăng nhập thất bại'}`);
    }
  };
  return (
    <div className="flex flex-col md:flex-row w-full md:w-4/7 mx-auto my-8 border rounded-2xl shadow-lg overflow-hidden bg-white mt-6">
      {/* Left column */}
      <div className="w-full md:w-[45%] bg-[#6a0000] p-2 flex flex-col justify-center items-center">
        <img src="/logo.png" alt="Logo" className="w-full h-auto" />
      </div>

      {/* Right column */}
      <div className="w-full md:w-[55%] p-8">
        <h2 className="text-2xl font-bold mb-6 text-black text-center">Đăng nhập thành viên</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className='mb-6'>
            <label className="block text-sm font-semibold">✉️ Email</label>
            <input  type="email" name="email" value={email} required
              onChange={ e => setEmail(e.target.value)}
              className="w-full border px-4 py-1 rounded-md focus:outline-none"
            />
          </div>
          <div className='mb-8'>
            <label className="block text-sm font-semibold">🔒 Mật khẩu</label>
            <input type="password" name="mat_khau" value={mat_khau} required
              onChange={ e => setMatKhau(e.target.value)}
              className="w-full border px-4 py-2 rounded-md focus:outline-none"
            />
          </div>
          <div className="flex items-center justify-between">
            <button type="submit"
              className="bg-[#6a0000] hover:bg-blue-700 text-white px-6 py-2 rounded-xl">
              Đăng nhập
            </button>
            <div className="text-sm space-x-3">
              <a href="/quen-mat-khau" className="text-blue-600 hover:underline">❓Quên mật khẩu</a>
              <a href="/dang-ky" className="text-green-600 hover:underline">➕ Đăng ký</a>
            </div>
          </div>
        </form>
        {thongbao && ( <div className="mt-4 font-bold text-red-600">{thongbao}</div>)}
      </div>
    </div>
)}
