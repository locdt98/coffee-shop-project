// app/dang-nhap/page.tsx
import LoginForm from "./LoginForm";
export default function Page() {
  
  return (
    <div className="p-4">
      <LoginForm />
    </div>
  );
}
