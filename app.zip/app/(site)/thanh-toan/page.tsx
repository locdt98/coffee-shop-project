"use client";
import { useRouter } from "next/navigation";
import { useState, useRef, useEffect } from "react";

export default function ThanhToan() {
  const [token, ganToken] = useState('');
  const [user, ganUser] = useState({ho_ten:'', email:'', dia_chi:'', dien_thoai:''});
  const [cart, setCart] = useState<any[]>([]);
  const thongbaoRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  useEffect(() => {
      let user = JSON.parse( sessionStorage.getItem('user') || "{}");
      const token = sessionStorage.getItem('token');
      if (!user || !token) {
        sessionStorage.setItem("returnUrl", "/thanh-toan")
        router.push('/dang-nhap');
      } else { 
        ganUser(user);
        ganToken(token)
      } 
   }, []);

  useEffect(() => {
    const storedCart = localStorage.getItem("cart");
    if (storedCart) setCart(JSON.parse(storedCart));
  }, []);

  const tongTien = cart.reduce((sum, sp) => sum + sp.so_luong * sp.gia, 0);

  const validateEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const validatePhone = (sdt: string) =>  /^0\d{9,10}$/.test(sdt.replace(/\s+/g, ""));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    thongbaoRef.current!.innerHTML = "";
    if (user.ho_ten.trim() === "") return (thongbaoRef.current!.innerHTML = "❌ Chưa nhập họ tên");
    if (user.dia_chi.trim() === "") return (thongbaoRef.current!.innerHTML="❌ Chưa nhập địa chỉ");
    if (!validatePhone(user.dien_thoai)) return (thongbaoRef.current!.innerHTML="❌ Phone sai");
    if (!validateEmail(user.email)) return (thongbaoRef.current!.innerHTML="❌ Email không hợp lệ");

    const opt = {
      method: "POST",
      body: JSON.stringify({
        ten_nguoi_nhan: user.ho_ten,
        email: user.email,
        dia_chi: user.dia_chi,
        dien_thoai: user.dien_thoai,
        trang_thai: "moi_tao"
      }),
      headers: { "Content-Type": "application/json" , 'authorization':'Bearer ' + token },
    };

    fetch("http://localhost:3000/api/luu_don_hang", opt)
      .then((res) => res.json())
      .then(async (data) => {
        thongbaoRef.current!.innerHTML = "✅ " + data.thongbao;
        if (data.dh) {
          await luuChiTiet(data.dh.id);
          router.push("/thanh-toan/hoan-tat");
        }
      })
      .catch((err) => {
        console.log("Lỗi gửi đơn hàng:", err);
        thongbaoRef.current!.innerHTML = "❌ Có lỗi xảy ra khi gửi đơn hàng";
      });
  };

  async function luuChiTiet(id_dh: number) {
    const url = "http://localhost:3000/api/luu_1sp_trong_gio_hang";
    const promises = cart.map((sp) => {
      const body = {
        id_dh,
        id_sp: sp.id,
        gia: sp.gia,
        sku: sp.sku,
        so_luong: sp.so_luong,
      };
      return fetch(url, {
        method: "POST",
        body: JSON.stringify(body),
        headers: { "Content-Type": "application/json", 'authorization':'Bearer ' + token  },
      });
    });
    await Promise.all(promises);
    localStorage.removeItem("cart");
  }

  return (
    <div className="w-11/12 mx-auto grid md:grid-cols-3 gap-2 mt-6">
      {/* LEFT: Cart Summary */}
      <div className="md:col-span-1 bg-neutral-100 rounded shadow p-4">
        <h3 className="text-lg font-semibold mb-3 text-amber-700">Giỏ hàng</h3>
        {cart.length === 0 ? (<p className="italic text-gray-500">Giỏ hàng trống</p> ) : 
        (
          <div className="space-y-2 text-sm">
            {cart.map((sp, idx) => (
              <div key={idx} className="flex justify-between border-b py-2">
                <div>{sp.ten_sp} <span className="text-gray-900"> x {sp.so_luong}</span></div>
                <div>{(sp.gia * sp.so_luong).toLocaleString()} VNĐ</div>
              </div>
            ))}
            <div className="font-bold text-right text-red-500 pt-2  mt-2">
              Tổng: {tongTien.toLocaleString()} VNĐ
            </div>
          </div>
        )}
        <button  onClick={() => router.push("/")}
          className="mt-4 text-sm text-cyan-700 hover:underline">
         ← Tiếp tục mua hàng
        </button>
      </div>

      {/* RIGHT: Checkout Form */}
      <form  onSubmit={handleSubmit}
        className="md:col-span-2 bg-white border shadow p-6 rounded">
        <h2 className="text-xl font-bold text-amber-700 mb-4">Thông tin thanh toán</h2>

        <div className="mb-3">
          <label className="block mb-1">Họ tên</label>
          <input type="text"  value={user.ho_ten}
            className="w-full border rounded px-3 py-2 bg-zinc-50 outline-none"
            onChange={(e) => ganUser({...user, ho_ten: e.target.value})}
          />
          {user.ho_ten.length < 6 && <p className="text-orange-600 text-sm">Ít nhất 6 ký tự</p>}
        </div>

        <div className="mb-3">
          <label className="block mb-1">Email</label>
          <input type="email"   value={user.email}
           className="w-full border rounded px-3 py-2 bg-zinc-50 outline-none"
           onChange={(e) => ganUser({...user, email: e.target.value})}
          />
          { (user.email.length == 0) && <p className="text-orange-600 text-sm">Email chưa đúng</p> }
        </div>

        <div className="mb-3">
          <label className="block mb-1">Địa chỉ</label>
          <input type="text"   value={user.dia_chi}
            className="w-full border rounded px-3 py-2 bg-zinc-50 outline-none"
            onChange={(e) => ganUser({...user, dia_chi: e.target.value})}
          />
          {user.dia_chi.length < 10 && (
            <p className="text-orange-600 text-sm">Nhập ít nhất 10 ký tự</p>
          )}
        </div>

        <div className="mb-3">
          <label className="block mb-1">Điện thoại</label>
          <input  type="text"  value={user.dien_thoai}
            className="w-full border rounded px-3 py-2 bg-zinc-50 outline-none"
            onChange={ e => ganUser({...user, dien_thoai: e.target.value})}
          />
          { (user.dien_thoai.length < 9 || user.dien_thoai.length > 10) &&  (
            <p className="text-orange-600 text-sm">Điện thoại 9 hoặc 10 số</p>
          )}
        </div>

        <div  ref={thongbaoRef}  className="text-red-600 font-semibold italic mb-2"></div>

        <button type="submit" 
          className="bg-cyan-600 hover:bg-cyan-700 text-white px-6 py-2 rounded shadow font-semibold"> Xác nhận & Đặt hàng</button>
      </form>
    </div>
)}
