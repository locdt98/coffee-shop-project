'use client'
import { useState } from 'react';

export default function HinhSP({ hinhChinh, hinhPhu }: { hinhChinh: string, hinhPhu: string[] }) {
  const [hinh, setHinh] = useState(hinhChinh);
  return (
    <div className="flex flex-col items-center">
      <img src={hinh} alt="Hình chính" width={450} height={300} className="rounded mb-4 shadow-md"/>
      <div className="flex space-x-2">
        {[hinhChinh, ...hinhPhu].map((h, i) => (
          <img  key={i} src={h} alt={`Hình ${i}`} width={60} height={60}
            onClick={() => setHinh(h)}
            className={`cursor-pointer rounded border-2 ${hinh === h ? 'border-red-600' : 'border-transparent'}`}
          />
        ))}
      </div>
    </div>
)}
