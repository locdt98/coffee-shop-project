import Link from "next/link";
import HinhSP from "./HinhSP";
import { ISanPham } from "@/app/components/cautrucdata";
import FormBinhLuan from "./FormBinhLuan";
type Props = { params: { slug: string  }   }

export default async function ChitietSP({ params }: Props)  {
  const { slug } =  await params;
  const res = await fetch(`http://localhost:3000/api/sp/${slug}`);
  const sp = await res.json();
  if (!sp) return <div>Không tìm thấy sản phẩm</div>;

  const resLQ = await fetch(`http://localhost:3000/api/sp_lien_quan/${sp.id}?limit=5`);
  const splienquan_arr = await resLQ.json() as ISanPham[];

  const resBL = await fetch(`http://localhost:3000/api/binh_luan/${sp.id}`);
  const binhluan_arr = await resBL.json();

  // Mảng mã khuyến mãi demo
  const khuyenMaiArr = ["TET2025", "GIAMGIA20", "FREESHIP"];

  return (
    <main className="bg-[#f5e6d3] text-[#3e2f23] p-8 text-lg leading-loose">
      <div className="grid grid-cols-1 md:grid-cols-[40%_60%] gap-8">
        <div>  <HinhSP hinhChinh={sp.hinh} hinhPhu={sp.hinh_phu || []} />  </div>
        <div>
          <h1 className="text-4xl font-bold mb-4">{sp.ten_sp}</h1>
          <div className="text-2xl font-semibold text-red-600 mb-4">
             Giá: {Number(sp.gia).toLocaleString("vi")}đ</div>
          <div className="mt-2"><b>Thành phần:</b> {sp.thanh_phan}</div>
          <div className="mt-2"><b>Hương vị:</b> {sp.huong_vi}</div>
          <div className="mt-2"><b>Khối lượng:</b> {sp.khoi_luong}</div>
          <div className="mt-2"><b>Bảo quản:</b> {sp.huong_dan_bao_quan}</div>
          <div className="mt-2"><b>Hạn sử dụng:</b> {sp.han_su_dung}</div>
          <div className="mt-2"><b>Mã kh. mãi: </b> 
            {khuyenMaiArr.map((ma: string, index: number) => (
              <span key={index}
                className="inline-block border border-[#3e2f23] text-[#3e2f23] px-2 py-1 text-sm mr-2 rounded">#{ma}</span>
            ))}
          </div>
          <div className="mt-2">
            <b>Các tags : </b> 
            {sp.tags?.map((tag: string, index: number) => (
              <span key={index}
                className="inline-block border border-[#3e2f23] text-[#3e2f23] px-2 py-1 text-sm mr-2 rounded">#{tag}</span>
            ))}
          </div>
          <div className="mt-2 flex items-center space-x-4">
            <label htmlFor="soLuong"><b>Số lượng:</b></label>
            <input id="soLuong" type="number" min="1" max={sp.so_luong || 1}
              defaultValue={sp.so_luong || 1} className="w-20 border rounded px-2  h-[32px]"/>
          </div>

          <div className="mt-3 space-x-4">
            <button className="bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-1 rounded">Thêm vào giỏ</button>
            <button className="bg-orange-500 hover:bg-orange-600 text-white font-semibold px-4 py-1 rounded">Mua hàng</button>
          </div>
        </div>
      </div>

      {/* sản phẩm liên quan*/}
      { splienquan_arr.length > 0 && (
          <div id="splienquan" className="mt-10">
              <h2 className="text-2xl font-semibold mb-4 text-center">Sản phẩm liên quan</h2>
              <div className="flex flex-wrap justify-center gap-6">
              {splienquan_arr.map( sp => (
              <div key={sp.id} className="w-[calc(49%-12px)] md:w-[calc(31%-15px)] lg:w-[calc(19%-15px)] bg-white rounded-lg shadow p-4 text-center">
                  <img src={sp.hinh} alt={sp.ten_sp} className="w-full h-40 object-cover rounded mb-3" />
                  <h3 className="font-medium h-[55px] leading-[120%]">
                  <Link href={`/sp/${sp.slug}`}>{sp.ten_sp}</Link>
                  </h3>
                  <p className="text-[#8b4513] font-semibold">{sp.gia.toLocaleString()}₫</p>
                  <button className="mt-2 px-2 py-0 bg-green-600 text-white rounded hover:bg-[#6c3610]">
                  Thêm vào giỏ
                  </button>
              </div>
              ))}
              </div>
          </div>
      )}

      {/* bình luận của sản phẩm */}

      {binhluan_arr.length > 0 && (
      <div id="listbinhluan" className="mt-10">
          <h2 className="text-2xl font-semibold mb-3 text-center">Bình luận sản phẩm</h2>
          <div className="space-y-4">
              { binhluan_arr.map( (bl:any) => (
              <div key={bl.id} className="p-4 bg-white rounded-lg shadow my-1">
                  <div className="text-lg font-medium text-[#3e2f23]">
                  <b>{bl.ho_ten}</b> - 
                  <i className="text-sm text-gray-600 italic mb-1 ml-2">
                    {new Date(bl.updatedAt).toLocaleDateString("vi")} 
                  </i>
                  </div>
                  <div className="text-[#3e2f23]">{bl.noi_dung}</div>
              </div>
              ))}
          </div>
      </div>
      )}
      <FormBinhLuan></FormBinhLuan>
    </main>
)}
