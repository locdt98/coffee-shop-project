"use client"
import { useState } from "react";

export default function FormBinhLuan() {
  const [hoTen, setHoTen] = useState("");
  const [email, setEmail] = useState("");
  const [noiDung, setNoiDung] = useState("");
  const [daGui, setDaGui] = useState(false);
  const maxKyTu = 200;

  const handleSubmit = (e) => {
    e.preventDefault();
    // gửi về server tại đây 
    setDaGui(true);
  };
  if (daGui) {
    return <div className="text-green-600 text-lg font-semibold mt-4 text-center">
        Cảm ơn bạn đã gửi bình luận!
    </div>;
  }

  return (
  <form onSubmit={handleSubmit} className="w-5/7 m-auto bg-white shadow p-4 rounded space-y-4 mt-6">
      <h3 className="text-xl font-bold">Gửi bình luận</h3>
      <input  type="text" placeholder="Họ tên" value={hoTen} required
        onChange={e=>setHoTen(e.target.value)} className="w-full border rounded p-1 outline-none"/>
      <input  type="email" placeholder="Email" value={email} required
        onChange={e=>setEmail(e.target.value)} className="w-full border rounded p-1 outline-none" />
      <div className="relative">
        <textarea value={noiDung}  onChange={(e) => setNoiDung(e.target.value.slice(0, maxKyTu))}
          placeholder="Nội dung bình luận..." rows={3} required
          className="w-full border rounded p-1 pr-20 outline-none" />
        <div className="absolute bottom-3 right-3 text-sm text-gray-500">
          {maxKyTu - noiDung.length} ký tự còn lại
        </div>
      </div>
      <button type="submit"
        className="bg-green-600 hover:bg-green-800 text-white font-semibold px-4 py-0 rounded">
        Gửi bình luận
      </button>
    </form>
)}
