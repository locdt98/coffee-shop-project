import HomeBaiVietHot from "./components/HomeBaiVietHot";
import HomeHighlight from "./components/HomeHighlight";
import HomeProductsHot from "./components/HomeProductsHot";
import HomeProductsNew from "./components/HomeProductsNew";
import HomeSlideshow from "./components/HomeSlideshow";
import HomeTestimonials from "./components/HomeTestimonials";

export default async function Home() {
return (
    <main className="bg-[#f5e6d3] text-[#3e2f23]">
      {/* <HomeSlideshow></HomeSlideshow> */}
      <HomeProductsHot></HomeProductsHot>
      <HomeProductsNew></HomeProductsNew>
      <HomeHighlight></HomeHighlight>
      <HomeBaiVietHot></HomeBaiVietHot>
      <HomeTestimonials></HomeTestimonials>
    </main>
  );
}
