// app/lien-he/page.tsx
import LienHeForm from "./LienHeForm";
export default function LienHePage() {
    
  return (
    <div className="py-5">
      <LienHeForm />
    </div>
  );
}
