'use client';
import { useState } from 'react';

export default function LienHeForm() {
  const [ho_ten, setHoTen] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [noi_dung, setNoiDung] = useState('');
  const [gui_thanh_cong, setThanhCong] = useState(false);
  const maxChar = 500;
  
const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  const form = e.target as HTMLFormElement;
  try {
    const res = await fetch('http://localhost:3000/api/lien_he', {
      method: 'POST',
      headers: {'Content-Type': 'application/json', },
      body: JSON.stringify({ho_ten , email, noi_dung, phone }),
    });
    const data = await res.json();
    if (res.ok) {
      form.reset();
      setThanhCong(true)
    } else alert(`❌ Gửi thất bại: ${data?.thongbao || 'Lỗi không xác định'}`);
  } catch (err) {
    alert('❌ Có lỗi khi gửi liên hệ. ');
    console.log(err);
  }
};

return (
  <div className="flex flex-col md:flex-row items-center justify-center p-6 bg-white rounded-2xl shadow-xl max-w-5xl mx-auto mt-8">
    {/* Logo bên trái */}
    <div className="w-full md:w-1/2  mb-6 md:mb-0 ">
      <img src="/logo.png" alt="Logo" className="w-11/12 h-100" />
    </div>

    {/* Form bên phải */}
    
    {  gui_thanh_cong===true ? 
    (<div className='flex items-center justify-center h-[150px] p-4 w-full md:w-1/2 text-2xl bg-amber-300 font-bold my-5 rounded-xl'> 
      Liên hệ đã gửi đến ban quản trị. <br/>Cảm ơn quý khách
    </div> 
    ):
    (<div className="w-full md:w-1/2">
      <h2 className="text-2xl font-bold text-gray-800 mb-3  text-center md:text-left">
        Liên hệ với chúng tôi
      </h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Họ tên</label>
          <input type="text" required onChange={ e => setHoTen(e.target.value)}
            className="mt-1 w-full px-4 py-1 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-blue-200"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Email</label>
          <input  type="email" required onChange={ e => setEmail(e.target.value)}
            className="mt-1 w-full px-4 py-1 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-blue-200"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Phone</label>
          <input  type="text" required  onChange={ e => setPhone(e.target.value)}
            className="mt-1 w-full px-4 py-1 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-blue-200"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Nội dung</label>
          <textarea  rows={3} maxLength={maxChar} value={noi_dung} required 
            onChange={ e => setNoiDung(e.target.value)}
            placeholder="Nhập nội dung liên hệ..."
            className="mt-1 w-full px-4 py-1 border border-gray-300 rounded-lg resize-none focus:outline-none focus:ring focus:ring-blue-200"
          ></textarea>
          <p className="text-sm text-gray-500 text-right my-0">
            {maxChar - noi_dung.length} ký tự còn lại
          </p>
        </div>

        <button  type="submit"
          className="w-full py-1 px-4  bg-green-600 text-white rounded-lg hover:bg-green-800 transition"
        >
          Gửi liên hệ
        </button>
      </form>
    </div>
    )}
  </div>
  );
}
