"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

export default function ShowCart() {
  const [cart, setCart] = useState<any[]>([]);

  useEffect(() => {
    const storedCart = localStorage.getItem("cart");
    if (storedCart) setCart(JSON.parse(storedCart));
  }, []);

  const suaSL = (id: string, so_luong: number) => {
    const newCart = [...cart];
    const index = newCart.findIndex( item => item.id === id);
    if (index !== -1) {
      newCart[index].so_luong = so_luong > 0 ? so_luong : 1;
      setCart(newCart);
      localStorage.setItem("cart", JSON.stringify(newCart));
    }
  };

  const xoaSP = (id: string) => {
    // const index = cart.findIndex((item) => item.id === id);
    // const newCart = cart.splice(index,1);
     const newCart = cart.filter( item => item.id !== id);
    setCart(newCart);
    localStorage.setItem("cart", JSON.stringify(newCart));
  };

  const xoaGioHang = () => {
    setCart([]);
    localStorage.removeItem("cart");
  };

  const totalPrice = cart.reduce((sum, item) => sum + item.gia * item.so_luong, 0);

  return (
    <div className="mx-auto w-11/12 max-w-6xl my-6 text-[1.05em]">
      <h2 className="text-2xl font-bold mb-4 text-amber-700">🛒 Giỏ hàng của bạn</h2>

      {cart.length === 0 ? (
        <p className="text-lg text-gray-500 ">Giỏ hàng trống.</p>
      ) : (
        <div className="overflow-x-auto border border-gray-300 shadow-md rounded-lg">
          <table className="w-full text-left border-collapse">
            <thead className="bg-amber-600 text-white">
              <tr>
                <th className="p-3">STT</th>
                <th className="p-3">Hình</th>
                <th className="p-3">Tên sản phẩm</th>
                <th className="p-3 text-right">Giá</th>
                <th className="p-3 text-center">Số lượng</th>
                <th className="p-3 text-right">Thành tiền</th>
                <th className="p-3 text-center">Xóa</th>
              </tr>
            </thead>
            <tbody>
              {cart.map((sp: any, index: number) => (
                <tr key={index} className="hover:bg-amber-50 border-t">
                  <td className="p-3 text-center">{index + 1}</td>
                  <td className="p-3">
                    <img src={sp.hinh} alt={sp.ten_sp} className="w-16 h-16 object-cover rounded" />
                  </td>
                  <td className="p-3">{sp.ten_sp}</td>
                  <td className="p-3 text-right">{Number(sp.gia).toLocaleString("vi")} đồng</td>
                  <td className="p-3 text-center">
                    <input
                      type="number"
                      value={sp.so_luong}
                      min={1}
                      className="w-16 border rounded text-center"
                      onChange={ e => suaSL(sp.id, Number(e.target.value))}
                    />
                  </td>
                  <td className="p-3 text-right">
                    {(Number(sp.gia * sp.so_luong)).toLocaleString("vi")} đồng
                  </td>
                  <td className="p-3 ">
                    
                    <button onClick={() => xoaSP(sp.id)}
                    className="w-8 h-8 flex items-center justify-center bg-gray-300 hover:bg-gray-400 text-xl rounded-full" title="Xóa sản phẩm"> 🗑️ </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="flex justify-between items-center p-4 bg-gray-100 border-t">
            <div className="space-x-4">
              <button onClick={xoaGioHang}
                className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded"
              > Xóa giỏ hàng </button>
              <Link href="/">
                <button className="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded">
                  Tiếp tục mua hàng
                </button>
              </Link>
               <Link href="/thanh-toan">
                <button className="bg-green-600 hover:bg-green-800 text-white px-8 py-2 rounded">
                  Thanh toán
                </button>
              </Link>
            </div>
            <div className="text-lg font-bold text-amber-700">
              Tổng tiền: {Number(totalPrice).toLocaleString("vi")} đồng
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
