// app/quen-mat-khau/page.tsx
import QuenMatKhau from "./QuenMatKhau";
export default function Page() {
  
  return (
    <div className="p-4">
      <QuenMatKhau />
    </div>
  );
}
