'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function QuenMatKhau() {
  const router = useRouter();

  const [email, setEmail] = useState('');
  const [thongbao, setThongbao] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setThongbao('Đang kiểm tra...');

    const res = await fetch('http://localhost:3000/api/quen_pass', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({email:email})
    });
    const data = await res.json();
    console.log("email=", email)
    console.log("data=", data)
    
    if (data.status ==1 ) {
      setThongbao('✅ Thành công, vui lòng check mail để có mật khẩu mới...');
      setTimeout(() => { router.push('/dang-nhap') }, 3000);
    } else {
      setThongbao(`❌ ${data.message || 'Thất bại'}`);
    }
  };

  return (
    <div className="flex flex-col md:flex-row w-full md:w-4/7 mx-auto my-8 border rounded-2xl shadow-lg overflow-hidden bg-white mt-6">
      {/* Left column */}
      <div className="w-full md:w-[45%] bg-[#6a0000] p-2 flex flex-col justify-center items-center">
        <img src="/logo.png" alt="Logo" className="w-full h-auto" />
      </div>

      {/* Right column */}
      <div className="w-full md:w-[55%] p-8">
        <h2 className="text-2xl font-bold mb-8 text-black text-center">Quên mật khẩu</h2>
        <form  onSubmit={handleSubmit} className="space-y-4">
          <div className='mb-8'>
            <label className="block text-sm font-semibold">✉️ Email</label>
            <input  type="email" name="email" value={email} required
              onChange={ e => setEmail(e.target.value)}
              className="w-full border px-4 py-1 rounded-md focus:outline-none"
            />
          </div>
          <button type="submit"
              className="bg-[#6a0000] hover:bg-blue-700 text-white px-6 py-2 mb-6 rounded-xl">
              Gửi mật khẩu
          </button>
          <div className="text-sm space-x-3">
            <a href="/dang-nhap" className="text-blue-600 hover:underline">❓ Đăng nhập</a>
            <a href="/dang-ky" className="text-green-600 hover:underline">➕ Đăng ký</a>
          </div>
        </form>
        {thongbao && ( <div className="mt-4 font-bold text-red-600"> {thongbao} </div> )}
      </div>
    </div>
)}
