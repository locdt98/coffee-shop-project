import ListSP from "../components/ListSP";

export default async function SPTrongLoai( { searchParams }: { searchParams: { tu_khoa: string } }) {
  const { tu_khoa } =  await searchParams;
  const resSP = await fetch(`http://localhost:3000/api/tim_kiem?tu_khoa=${tu_khoa}`);
  const listsp = await resSP.json();

  return (<ListSP listsp={listsp} title={`Kết quả tìm từ khóa ${tu_khoa}`} />)
}
