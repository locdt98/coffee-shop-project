
import { IBaiViet } from "./cautrucdata";

export default async function HomeBaiVietHot() {
const resBaiViet = await fetch(`http://localhost:3000/api/bai_viet?limit=6`)
const baivietHot_arr = await resBaiViet.json();
return (
<section className="bg-[#fdfaf6] py-16 rounded-2xl shadow-md">
    <h2 className="text-3xl md:text-4xl text-center  font-semibold text-[#5a3e36] mb-10" style={{ fontFamily: "'Playfair Display', serif" }}>
        Góc chia sẻ
    </h2>
    <div className="max-w-6xl mx-auto grid md:grid-cols-3  gap-8">
        {baivietHot_arr.map((post:IBaiViet, index:number) => (
        <div key={index} className="bg-white shadow-md rounded-2xl overflow-hidden transition transform hover:-translate-y-1 hover:shadow-lg">
            <img src={post.hinh} alt={post.tieu_de} className="w-full h-48 object-cover" />
            <div className="p-6 text-left">
            <h3 className="text-xl font-bold text-[#4e342e] mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                {post.tieu_de}
            </h3>
            <div className="text-[#5d4037] text-sm leading-relaxed" style={{ fontFamily: "'Lora', serif" }} 
            dangerouslySetInnerHTML={{ __html: post.noi_dung }} />            
            </div>
        </div>
        ))}
    </div>
</section>

)}
