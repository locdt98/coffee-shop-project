'use client';
import { useState } from "react";
import { ISanPham } from "./cautrucdata";
import ProductCard from "./ProductCard";
export default function ListSP({ listsp, title }: { listsp: ISanPham[]; title: string }) {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 4;
  const totalPages = Math.ceil(listsp.length / itemsPerPage);
  const indexStart = (currentPage - 1) * itemsPerPage;  
  const currentSP = listsp.slice(indexStart, indexStart + itemsPerPage);

  const changePage = (page: number) => {
    if (page >= 1 && page <= totalPages) setCurrentPage(page);
  };

  return (
    <div className="mt-4 px-4">
        <h1 className="text-2xl font-bold mb-4">{title}</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {currentSP.map((product: ISanPham, index: number) => 
            <ProductCard key={product.id} product={product} index={index} />
            )}
        </div>

      {/* Phân trang */}
      <div className="flex justify-center items-center gap-2 mt-6">
        <button 
          onClick={() => changePage(currentPage - 1)} disabled={currentPage === 1}
          className="px-3 py-1 border rounded disabled:opacity-50">←
        </button>

        { Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
         <button key={page} onClick={() => changePage(page)}
         className={`px-3 py-1 border rounded ${page==currentPage? 'bg-green-600 text-white' : ''}`}
         > {page} </button>
          ))}

        <button onClick={() => changePage(currentPage + 1)} disabled={currentPage === totalPages}
          className="px-3 py-1 border rounded disabled:opacity-50">→</button>
      </div>
    </div>
)}
