'use client';
import { useState, useEffect } from 'react';
const resBanner = await fetch(`http://localhost:3000/api/banner`)
const banner_arr = await resBanner.json();
const length = banner_arr.length;

export default function HomeSlideshow() {
  const [current, setCurrent] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  const prevSlide = () => {
    setCurrent((current - 1 + length) % length);
  };

  const nextSlide = () => {
    setCurrent((current + 1) % length);
  };

  return (
    <div className="relative h-[450px] overflow-hidden">
      {banner_arr.map((item:any, i:any) => (
        <img  key={i} src={item.hinh} alt=""
          className={`absolute top-0 left-0 w-full h-full object-cover transition-opacity duration-1000 ${
            i === current ? 'opacity-100' : 'opacity-0'
          }`}
        />
      ))}

      {/* Nút điều hướng */}
      <button onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/70 p-2 rounded-full hover:bg-white"
      > ◀ </button>
      <button onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/70 p-2 rounded-full hover:bg-white"
      > ▶ </button>
    </div>
  );
}
