import { ISanPham } from "./cautrucdata"
import ProductCard from "./ProductCard";

const res = await fetch(`http://localhost:3000/api/sp_hot?limit=4`)
const product_arr = await res.json() as ISanPham[];

export default function HomeProductsHot(){ 
return <section className=" mx-auto px-4 pt-16 space-y-20">
        <h2 className="text-2xl font-bold text-teal-800 mb-6">☕ Sản phẩm nổi bật</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {product_arr.map( (product: ISanPham, index: number) => (
            <ProductCard key={product.id} product={product}  index={index} />
          ))}
        </div>
      </section>
}
