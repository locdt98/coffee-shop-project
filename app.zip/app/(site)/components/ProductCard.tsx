'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';
import AddToCart from './AddToCart';

export default function ProductCard({ product, index }: { product: any, index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="bg-white text-center rounded-xl shadow hover:shadow-lg transition p-4 flex flex-col justify-between relative"
    >
      {/* Hình ảnh */}
      <Link href={`/sp/${product.slug}`}>
        <img src={product.hinh} alt={product.ten_sp} width={"100%"} height={300}
          className="rounded-lg border object-cover w-full aspect-square"/>
      </Link>

      {/* Tên sp*/}
      <div className="mt-4 flex-1">
        <Link href={`/sp/${product.slug}`}>
          <h3 className="text-lg my-3 font-semibold text-gray-800 hover:text-teal-600 transition">
            {product.ten_sp}
          </h3>
        </Link>
      </div>
      <p className="text-teal-700 font-bold mt-1">{product.gia.toLocaleString("vi")} VNĐ</p>
      {product.tags && (
        <div className="text-sm font-semibold text-amber-600 inline-block px-2 py-0.5  my-1">
            {product.tags.join(" , ")}
        </div>
      )}
      {/* Nút giỏ hàng */}
      <AddToCart sp={product}></AddToCart>
    </motion.div>
)}
