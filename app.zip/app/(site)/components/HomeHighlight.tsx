import { Lora, Playfair_Display } from 'next/font/google';

const lora = Lora({ subsets: ['latin'], weight: '400', style: 'italic' });
const playfair = Playfair_Display({ subsets: ['latin'], weight: '500' });

export default function HomeHighlight() {
return (
<section
      className="relative text-white py-28 px-6 text-center bg-cover bg-center"
      style={{
        backgroundImage:
          "url('https://images.pexels.com/photos/1879386/pexels-photo-1879386.jpeg?auto=compress&cs=tinysrgb&w=1600')",
      }}
    >
      <div className="absolute inset-0 bg-[rgba(0,0,0,0.45)]"></div>

      <div className="relative z-10 max-w-4xl mx-auto">
        <h2 className={`text-3xl md:text-4xl mb-8 ${playfair.className}`}>
          Tách trà, khoảnh khắc – lặng im, hiện hữu.
        </h2>
        <p className={`text-xl md:text-2xl mb-5 leading-relaxed italic ${lora.className}`}>
           Khi ta nâng chén trà, mọi muộn phiền dừng lại. Không còn vội vã, không còn lo toan.
          Chỉ còn ta, trà, và phút giây này – trọn vẹn.
         </p>
         <p className={`text-xl md:text-2xl mb-5 leading-relaxed italic ${lora.className}`}>
           Ở nơi này, chúng tôi mong được đồng hành cùng bạn trên hành trình thưởng thức –
           chậm rãi, tinh tế, đầy cảm xúc.
         </p>
        <div className={`text-xl md:text-2xl mb-5 leading-relaxed italic ${lora.className}`}>
         <blockquote className="italic text-gray-200">
           “Uống trà không phải để giải khát, mà để trở về với chính mình.”  <br />
           <span className="block mt-1 text-sm text-gray-300">— Thiền sư Thích Nhất Hạnh</span>
         </blockquote>
        </div>

         <div className="mt-8">
           <a href="/products"
             className="inline-block px-6 py-3 text-white bg-[#6a0000] hover:bg-[#4e0000] rounded-full transition"
           > Khám phá thêm </a>
         </div>
      </div>
</section> 
)}
