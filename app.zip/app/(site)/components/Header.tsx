"use client";
import { useEffect, useState } from "react";
import Link from "next/link"
import { useSearchParams } from "next/navigation";

export default function Header() {
  const [cart, setCart] = useState<any[]>([]);
  const [ho_ten, setHoTen] = useState('');
 
  const searchParams = useSearchParams()
  const tu_khoa = searchParams.get("tu_khoa") || "";
  useEffect(() => {
      const user = JSON.parse(sessionStorage.getItem("user") || "{}");
      let ht = user.ho_ten || "Quý khách";
      setHoTen(ht);
      window.addEventListener("login", (e) => {
        const user = JSON.parse(sessionStorage.getItem("user") || "{}");
        let ht = user.ho_ten || "Quý khách";
        setHoTen(ht)
      });
  }, []);
  useEffect(() => {
      const storedCart = localStorage.getItem("cart");
      if (storedCart) setCart(JSON.parse(storedCart));
      window.addEventListener("themvaogio", (e) => {
        const storedCart = localStorage.getItem("cart");
        if (storedCart) setCart(JSON.parse(storedCart));
      });
  }, []);

return (
  <header className="bg-white shadow-md py-6 px-6 flex items-center justify-between">
    <div className="text-2xl font-bold text-[#6a0000]">Café Trà Zen</div>
    {/* Menu */}
    <nav className="hidden md:flex items-center space-x-6 text-[#3e2f23] text-base">
      <Link href={"/"} className="flex items-center gap-1 hover:text-[#6a0000]">
        <span>🏠</span> <span>Trang chủ</span>
      </Link>
      
      <Link href={"/san-pham"} className="flex items-center gap-1 hover:text-[#6a0000]">
        <span>📦</span> <span>Sản phẩm</span>
      </Link>

      <Link href={"/gioi-thieu"} className="flex items-center gap-1 hover:text-[#6a0000]">
        <span>🧘</span>  <span>Giới thiệu</span>
      </Link>

      <Link href={"/lien-he"} className="flex items-center gap-1 hover:text-[#6a0000]">
        <span>✉️</span>  <span>Liên hệ</span>
      </Link>
    </nav>
    {/* Tìm kiếm + Cart + User */}
    <div className="flex items-center space-x-4">
      {/* Form tìm kiếm */}
      <form action={'/tim-kiem'} className="hidden md:flex items-center bg-[#f5e6d3] rounded px-2">
        <input type="text" placeholder="Tìm sản phẩm..." name="tu_khoa" defaultValue={tu_khoa}
          className="bg-transparent outline-none px-2 py-1 text-sm"
        />
        <button type="submit" className="text-[#6a0000]">🔍</button>
      </form>

      {/* Cart */}
      <Link href={"/gio-hang"} className="relative flex items-center gap-1 text-[#3e2f23] hover:text-[#6a0000]">
        🛒 <span>Giỏ hàng</span>
        <span className="absolute -top-2 -right-2 bg-[#6a0000] text-white text-xs rounded-full px-1"> {cart.length}</span>
      </Link>

      {/* User info */}
      <Link href="#" className="flex items-center gap-1 hover:text-[#6a0000]">
        👤 <span>{ho_ten}</span>
      </Link>
    </div>
  </header>
)}
