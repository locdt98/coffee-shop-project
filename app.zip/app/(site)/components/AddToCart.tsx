"use client";
import { ICart } from "./cautrucdata";
export default function AddToCart( { sp }: { sp: any }) {
const themVaoGio = () => {
    let storedCart = localStorage.getItem("cart");
    let newCart = storedCart ? JSON.parse(storedCart) as ICart[]  : [];
    const index = newCart.findIndex((item: ICart) => item.id === sp.id);
    if (index !== -1) newCart[index].so_luong += 1; // Nếu đã có, tăng số lượng
    else newCart.push({ ...sp, so_luong: 1 }); // Nếu chưa có, thêm mới
    localStorage.setItem("cart", JSON.stringify(newCart)); // Lưu vào localStorage
    window.dispatchEvent(new CustomEvent("themvaogio", { detail: sp }));
};
return (
<button className="mt-4 bg-teal-600 hover:bg-teal-700 text-white py-2 px-4 rounded-lg text-sm transition"
onClick={themVaoGio} >  
   <i className="fa-solid fa-cart-plus mr-2"></i>
   Thêm vào giỏ 
</button>
)}
