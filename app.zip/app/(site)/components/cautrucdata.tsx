
export interface ILoai {
    id:number;
    ten_loai:string;
    slug: string; 
    thu_tu:number;
    an_hien:number;
    hinh:string;
    mo_ta:string;
}

export interface ISanPham {
    id:number;
    ten_sp:string;
    slug: string; 
    id_loai:number;
    sku:string; 
    hinh:string;
    hinh_phu:[string]
    gia:number;
    an_hien:string;
    hot:string;
    luot_xem:number;
    so_luong:number;
    thanh_phan:string;
    huong_vi:string;
    khoi_luong:string;
    huong_dan_bao_quan:string;
    han_su_dung:string;
    tags:[string]
}
export interface ITestimonial {
    name:string;
    title:string;
    quote: string;
}

export interface IBinhLuan {
    id:number;
    ho_ten:string;
    noi_dung:string;
    updatedAt:string;
}
export interface ICart {
    id : number 
    ten_sp: string;
    so_luong:number;
    gia_mua : number;
    hinh: string;
}

export interface IBanner {
    id : number 
    title: string;
    thu_tu:number;
    an_hien : boolean;
    hinh: string;
}
export interface IBaiViet {
    id:number;
    tieu_de:string;
    slug: string; 
    hinh:string;
    noi_dung:string;
    an_hien:boolean;
    hot:boolean;
    luot_xem:number;
}

