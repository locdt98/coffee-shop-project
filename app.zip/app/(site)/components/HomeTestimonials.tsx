import { ITestimonial } from "./cautrucdata";
const testimonials_arr:ITestimonial[] = [
  {
    name: 'Ngọc Trâm', title: 'Nhà trị liệu tâm lý',
    quote: 'Mỗi lần đến đây, tôi cảm thấy như được trở về với chính mình. Không gian, trà và cả sự tĩnh lặng đều thật tuyệt vời.',
  },
  {
    name: 'Minh Thiện', title: 'Doanh nhân',
    quote: 'Một nơi lý tưởng để khởi đầu ngày mới hoặc kết thúc ngày dài. Tôi tìm thấy sự bình an từ những điều giản dị ở đây.',
  },
  {
    name: 'Lan Phương', title: 'Nghệ sĩ múa',
    quote: 'Tôi yêu không gian nơi này. Mỗi tách trà là một bài thơ, và sự tĩnh tại giúp tôi kết nối sâu sắc với bản thân.',
  },
  {
    name: 'Hữu Tài',  title: 'Thiền sinh',
    quote: 'Tôi tìm thấy năng lượng chữa lành và cảm hứng thiền hành mỗi khi ngồi trong góc nhỏ của quán.',
  },
];

export default function HomeTestimonials(){
return  <section className=" py-20 mt-0 rounded-xl border border-gray-200">
    <h2 className="text-3xl md:text-4xl text-center font-semibold text-[#4e342e] mb-10" style={{ fontFamily: "'Playfair Display', serif" }}>
    Khách hàng nói gì?
    </h2>
    <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8">
    {testimonials_arr.map( (item:ITestimonial, index:number) => (
        <div key={index} className="bg-white shadow-sm rounded-xl p-6 text-left border-l-4 border-[#c7a17a]">
            <p className="text-[#5d4037] italic mb-4 leading-relaxed" style={{ fontFamily: "'Lora', serif" }}>
                “{item.quote}”
            </p>
            <div className="text-sm text-[#6d4c41] font-medium text-right">
                — {item.name}, {item.title}
            </div>
        </div>
    ))}
    </div>
</section>
}
