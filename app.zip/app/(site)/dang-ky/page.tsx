'use client'
import { useState } from 'react'

export default function DangKy() {
  const [ho_ten, setHoTen] = useState('')
  const [email, setEmail] = useState('')
  const [mat_khau, setMatKhau] = useState('')
  const [go_lai, setGoLai] = useState('')
  const [dia_chi, setDiaChi] = useState('')
  const [dien_thoai, setDienThoai] = useState('')

  const [errors, setErrors] = useState<{ [key: string]: string }>({}) //errors = [ 'ho_ten'=> 'asdad', 'email'=> 'adasd']
  const [success, setSuccess] = useState(false); // nếu thành công hoàn toàn thì true
  const [message, setMessage] = useState(""); //thông báo gửi lỗi từ server về 

  const validate = () => {
    const errs: { [key: string]: string } = {}
    if (!ho_ten) errs.ho_ten = 'Họ tên bắt buộc'
    if (!email) errs.email = 'Email bắt buộc'
    else if (!/\S+@\S+\.\S+/.test(email)) errs.email = 'Email không hợp lệ'
    if (
      mat_khau.length < 8 ||
      !/[A-Z]/.test(mat_khau) ||
      !/[a-z]/.test(mat_khau) ||
      !/[0-9]/.test(mat_khau) ||
      !/[\W_]/.test(mat_khau)
    ) {
      errs.mat_khau = 'Mật khẩu phải >= 8 ký tự, có chữ hoa, thường, số và ký tự đặc biệt';
    }
    if (mat_khau !== go_lai) errs.go_lai = 'Mật khẩu không khớp'
    if (!/^\d{9,10}$/.test(dien_thoai)) errs.dien_thoai = 'Điện thoại không hợp lệ'  
    return errs
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setMessage("")
    const errs = validate()
    setErrors(errs)
    if (Object.keys(errs).length === 0) {
      try {
        const res = await fetch('http://localhost:3000/api/dang_ky', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ho_ten, email, mat_khau, go_lai, dia_chi, dien_thoai}),
        })
        const data = await res.json();
        if (data.message!=undefined) 
          setMessage(data.message)
        else 
          setSuccess(true); // state success để hiện chữ thành công
      } catch (err) {
        alert('Lỗi server')
        console.log("err=", err)
      }
    }
  }

  return (
  <div className="flex flex-col items-center justify-center p-4">
      <div className="bg-white rounded-xl w-full max-w-5xl grid grid-cols-1 md:grid-cols-[45%_55%]">
        {/* Cột trái */}
        <div className="bg-[#6a0000] flex flex-col items-center justify-center p-6 space-y-4">
          <h2 className="text-3xl font-bold text-white">Đăng ký thành viên</h2>
          <img src="/logo.png" alt="Logo" className="w-[90%]" />
        </div>

        {/* Cột phải */}
        {success? 
        ( <div className="p-6 space-y-4 text-center">
             <h2 className="text-2xl font-bold mt-[100px]">Cảm ơn quý khách đã đăng ký</h2>
             <p className="text-xl font-bold">Xin mời kiểm tra mail để xác thực tài khoản</p>
          </div>
        ):
        ( <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="flex flex-col">
            <label>Họ tên *</label>
            <input value={ho_ten} onChange={ e => setHoTen(e.target.value)} 
            className="p-1 rounded outline-none border-1  border-[#6a0000]" />
            {errors.ho_ten && <small className="text-red-500">{errors.ho_ten}</small>}
          </div>

          <div className="flex flex-col">
            <label>Email *</label>
            <input value={email} onChange={ e => setEmail(e.target.value)} 
            className="p-1 rounded outline-none border-1  border-[#6a0000]" />
            {errors.email && <small className="text-red-500">{errors.email}</small>}
          </div>

          <div className="flex flex-col">
            <label>Mật khẩu *</label>
            <input type="password" value={mat_khau} onChange={ e => setMatKhau(e.target.value)} 
            className="p-1 rounded outline-none border-1  border-[#6a0000]" />
            {errors.mat_khau && <small className="text-red-500">{errors.mat_khau}</small>}
          </div>

          <div className="flex flex-col">
            <label>Gõ lại mật khẩu *</label>
            <input type="password" value={go_lai} onChange={ e => setGoLai(e.target.value)} 
            className="p-1 rounded outline-none border-1  border-[#6a0000]" />
            {errors.go_lai && <small className="text-red-500">{errors.go_lai}</small>}
          </div>

          <div className="flex flex-col">
            <label>Điện thoại *</label>
            <input value={dien_thoai} onChange={ e => setDienThoai(e.target.value)} 
            className="p-1 rounded outline-none border-1  border-[#6a0000]" />
            {errors.dien_thoai && <small className="text-red-500">{errors.dien_thoai}</small>}
          </div>

          <div className="flex flex-col">
            <label>Địa chỉ</label>
            <input value={dia_chi} onChange={ e => setDiaChi(e.target.value)} 
            className="p-1 rounded outline-none border-1  border-[#6a0000]" />
          </div>

          <div className="flex items-center justify-between mt-4">
            <button type="submit" 
            className="bg-[#6a0000] text-white px-8 py-2 rounded hover:bg-sky-700"> Đăng ký 
            </button>
           <div className="space-x-4">
           <a href="/dang-nhap" className="text-bg-[#6a0000] hover:underline">Đăng nhập</a>
           <a href="/quen-mat-khau" className="text-bg-[#6a0000]0 hover:underline">Quên mật khẩu</a>
           </div>
          </div>
          { message && <div className="text-red-500 font-bold"> {message} </div> }
        </form>
        )}
      </div>
    </div>
)}

