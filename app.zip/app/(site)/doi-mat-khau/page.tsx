'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function DoiMatKhau() {
  const [token, setToken] = useState('');
  const [user, setUser] = useState({email:'', old_pass:'', new_pass:'', re_new_pass:''})
  const [errors, setErrors] = useState<any>({});
  const [message, setMessage] = useState('');
  const router = useRouter();

  useEffect(() => {
    let user = JSON.parse( sessionStorage.getItem('user') || "{}");
    const token = sessionStorage.getItem('token');
    if (!user || !token) {
      sessionStorage.setItem("returnUrl", "/doi-mat-khau")
      router.push('/dang-nhap');
    } else { 
      setUser(user);
      setToken(token)
    } 
  }, [router]);

  const isStrongPassword = (password: string) => { 
    if (!password) return false;
    return password.length >= 8 && 
      /[A-Z]/.test(password) && //chữ hoa
      /[a-z]/.test(password) &&  // chữ thường
      /\d/.test(password) &&     //số
      /[^A-Za-z0-9]/.test(password) // ký tự đặc biệt
  }

  const validate = () => {
    const errs: any = {};
    if (!user.old_pass) errs.old_pass = 'Vui lòng nhập mật khẩu cũ';
    if (!isStrongPassword(user.new_pass)) errs.new_pass = 'Mật khẩu phải mạnh và >= 8 ký tự';
    if (user.new_pass !== user.re_new_pass) errs.re_new_pass = 'Mật khẩu mới không giống nhau';
    return errs;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length === 0) {
      try {
        const res = await fetch('http://localhost:3000/api/doi_pass', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'authorization':'Bearer ' + token },
          body: JSON.stringify(user),
        });
        const data = await res.json();
        if (data.status === 1) {
          setMessage('✅ Đổi mật khẩu thành công! Chuyển về trang chủ...');
          setTimeout(() => { router.push('/') }, 3000);
        } else {
          setMessage('❌ ' + (data.message || 'Lỗi đổi mật khẩu'));
        }
      } catch (err) {
        setMessage('❌ Lỗi hệ thống');
      }
    }
  };

  return (
    <div className="w-[70%] mx-auto my-10 grid grid-cols-1 md:grid-cols-[50%_50%] gap-6 items-center bg-white shadow-xl rounded-xl overflow-hidden">
      {/* Left: Form */}
      <div className="p-3">
        <h2 className="text-2xl font-bold text-[#6a0000] mb-4 text-center">Đổi mật khẩu</h2>
        <form onSubmit={handleSubmit} className="space-y-4 text-sm">
          <div>
            <label>🔒 Email</label>
            <input type="email" name="email" value={user.email} disabled
              className="w-full border px-2 py-2 outline-none"/>
          </div>
          <div>
            <label>🔒 Mật khẩu cũ</label>
            <input  type="password" onChange={ e => setUser( {...user,old_pass: e.target.value})}
              className="w-full border px-2 py-2 outline-none" />
            {errors.old_pass && <div className="text-red-500">{errors.old_pass}</div>}
          </div>
          <div>
            <label>🔒 Mật khẩu mới</label> 
            <input type="password" onChange={ e => setUser( {...user,new_pass: e.target.value})}
              className="w-full border px-2 py-2  outline-none"/>
            {errors.new_pass && <div className="text-red-500">{errors.new_pass}</div>}
          </div>
          <div>
            <label>🔁 Gõ lại mật khẩu mới</label>
            <input type="password" onChange={ e => setUser( {...user,re_new_pass: e.target.value})}
              className="w-full border px-2 py-2 outline-none"/>
            {errors.re_new_pass && <div className="text-red-500">{errors.re_new_pass}</div>}
          </div>
          <button  type="submit"
            className="bg-[#6a0000] hover:bg-blue-700 text-white w-full py-2 rounded mt-2"> 
            Đổi mật khẩu
          </button>
        </form>

        {message && <div className="mt-4 text-center font-semibold">{message}</div>}

        <div className="flex justify-between mt-6 text-sm text-blue-600">
          <a href="/">🏠 Trang chủ</a>
          <a href="/thoat">🚪 Thoát</a>
        </div>
      </div>

      {/* Right: Logo */}
      <div className="flex items-center bg-[#6a0000] h-full p-4">
          <img src="/logo.png" alt="Logo" className="w-[95%]" />
      </div>
    </div>
)}
